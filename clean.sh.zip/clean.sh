rm softdir/* configuredir/* remotecomdir/* updatedir/*  -rf
rm -f logs/*.log
echo "清理完成"
